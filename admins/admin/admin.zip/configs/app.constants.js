angular.module('train_admin')
     .constant('train_ADMIN_URL', 'http://trained.ignivastaging.com:8029/v1/')

    .constant('LOADER',"")
